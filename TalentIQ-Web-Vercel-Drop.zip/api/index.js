import worker from "../worker.js";

function headerObject(headers) {
  const out = {};
  for (const [key, value] of Object.entries(headers || {})) {
    if (Array.isArray(value)) out[key] = value.join(", ");
    else if (value !== undefined) out[key] = value;
  }
  return out;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", chunk => chunks.push(chunk));
    req.on("end", () => resolve(chunks.length ? Buffer.concat(chunks) : undefined));
    req.on("error", reject);
  });
}

export default async function handler(req, res) {
  const protocol = req.headers["x-forwarded-proto"] || "https";
  const host = req.headers.host || "localhost";
  const url = `${protocol}://${host}${req.url}`;
  const body = ["GET", "HEAD"].includes(req.method) ? undefined : await readBody(req);
  const request = new Request(url, {
    method: req.method,
    headers: headerObject(req.headers),
    body
  });
  const response = await worker.fetch(request, {
    GROQ_API_KEY: process.env.GROQ_API_KEY,
    GROQ_MODEL: process.env.GROQ_MODEL,
    RECRUITER_EMAILS: process.env.RECRUITER_EMAILS,
    ALLOWED_EVENT_CODES: process.env.ALLOWED_EVENT_CODES
  });

  res.statusCode = response.status;
  response.headers.forEach((value, key) => res.setHeader(key, value));
  const buffer = Buffer.from(await response.arrayBuffer());
  res.end(buffer);
}
