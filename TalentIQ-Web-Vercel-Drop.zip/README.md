# TalentIQ Vercel Drop package

Drag this ZIP into Vercel Drop.

After import, add these environment variables in Vercel Project Settings:

```txt
GROQ_API_KEY=your_groq_key_here
GROQ_MODEL=openai/gpt-oss-20b
RECRUITER_EMAILS=your-allowed-recruiter-email@example.com
ALLOWED_EVENT_CODES=DEMO
```

Then redeploy and visit:

```txt
/api/health
```

The response should include:

```json
{"aiConfigured":true}
```

Important: the original app was built for ChatGPT Sites/Worker bindings and expects `DB` and `UPLOADS` bindings for candidate records and resume files. This Vercel Drop package includes the frontend and a Vercel API wrapper so the Groq key can be read server-side, but full candidate storage needs a Vercel-compatible database and file-storage replacement before production use.
